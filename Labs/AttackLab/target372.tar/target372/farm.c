/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_353(unsigned *p)
{
    *p = 3284601160U;
}

void setval_416(unsigned *p)
{
    *p = 2425641125U;
}

unsigned addval_197(unsigned x)
{
    return x + 3264239653U;
}

unsigned addval_498(unsigned x)
{
    return x + 2421741825U;
}

unsigned addval_244(unsigned x)
{
    return x + 3347925190U;
}

void setval_417(unsigned *p)
{
    *p = 3284633928U;
}

void setval_458(unsigned *p)
{
    *p = 1477071663U;
}

void setval_283(unsigned *p)
{
    *p = 2428995912U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_124(unsigned *p)
{
    *p = 3677405833U;
}

unsigned getval_245()
{
    return 3269495112U;
}

unsigned addval_391(unsigned x)
{
    return x + 3374371213U;
}

unsigned addval_337(unsigned x)
{
    return x + 2464188744U;
}

unsigned addval_334(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_192()
{
    return 3285092805U;
}

unsigned getval_335()
{
    return 3223376267U;
}

void setval_134(unsigned *p)
{
    *p = 3286239560U;
}

void setval_472(unsigned *p)
{
    *p = 2430634312U;
}

void setval_381(unsigned *p)
{
    *p = 3281044105U;
}

unsigned addval_281(unsigned x)
{
    return x + 2445445420U;
}

unsigned addval_227(unsigned x)
{
    return x + 2462222597U;
}

unsigned getval_291()
{
    return 3251734888U;
}

unsigned getval_366()
{
    return 3531915917U;
}

unsigned getval_177()
{
    return 3224945293U;
}

unsigned addval_121(unsigned x)
{
    return x + 3281047961U;
}

void setval_428(unsigned *p)
{
    *p = 2429651422U;
}

unsigned getval_118()
{
    return 3676361089U;
}

unsigned addval_446(unsigned x)
{
    return x + 3286272332U;
}

unsigned getval_151()
{
    return 4207133353U;
}

void setval_175(unsigned *p)
{
    *p = 3281047176U;
}

unsigned addval_141(unsigned x)
{
    return x + 3372273289U;
}

void setval_234(unsigned *p)
{
    *p = 2425409801U;
}

unsigned addval_309(unsigned x)
{
    return x + 2429454488U;
}

void setval_451(unsigned *p)
{
    *p = 3680554633U;
}

unsigned addval_352(unsigned x)
{
    return x + 3677933065U;
}

unsigned getval_138()
{
    return 3525365385U;
}

unsigned getval_470()
{
    return 2425474697U;
}

void setval_215(unsigned *p)
{
    *p = 3767077057U;
}

void setval_388(unsigned *p)
{
    *p = 3372798345U;
}

unsigned getval_482()
{
    return 3526935177U;
}

void setval_419(unsigned *p)
{
    *p = 3269495112U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
